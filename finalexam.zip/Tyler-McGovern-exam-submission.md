# Final Submission

## Question 1
![q1.1](q1.1.png)
![q1.2](q1.2.png)
![q1.3](q1.3.png)

## Question 2
![q2.1](q2.1.png)
![q2.2](q2.2.png)
![q2.3](q2.3.png)
![q2.4](q2.4.png)
![q2.5](q2.5.png)
![q2.6](q2.6.png)
![q2.7](q2.7.png)

## Question 3
![q3.1](q3.1.png)